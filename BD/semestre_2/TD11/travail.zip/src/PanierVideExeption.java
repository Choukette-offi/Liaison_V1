public class PanierVideExeption extends Exception {
    public PanierVideExeption(String message) {
        super(message);
    }
}