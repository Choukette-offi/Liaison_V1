import javafx.application.Application;

public class Executable {
    public static void main(String[] args){
        // Permet d'instancier et de lancer l'application AppliDessin
        Application.launch(AppliSomme.class, args);
    }
}
