import java.util.ArrayList;
import java.util.List;

public class Panier{
    private List<Oeuf> lesOeufs;

    public Panier() {
        this.lesOeufs = new ArrayList<>();
    }

    public void ajouterOeuf(Oeuf oeuf) {
        lesOeufs.add(oeuf);
    }

    public int poidsTotal(Oeuf oeuf) throws PanierVideExeption {
        if (lesOeufs.isEmpty()) {
            throw new PanierVideExeption("Le panier est vide");
        }
        else{
            int qte = 0;
            for(Oeuf o : lesOeufs){
                qte += (o.getPoids() * o.getQte());
            }
            return qte;
        }
    }

    public int quantiteDe(String type) throws PasDeTelTypeDOeufExeption {
        int qte = 0;
        for(Oeuf o : lesOeufs){
            if(o.getType().equals(type)){
                qte += o.getQte();
            }
        }
        if(qte == 0){
            throw new PasDeTelTypeDOeufExeption("Pas de tel type d'oeuf");
        }
        return qte;
    }
}
