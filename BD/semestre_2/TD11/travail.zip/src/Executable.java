public class Executable {
    public static void main(String[] args){
        Panier panier = new Panier();
        Oeuf oeuf1 = new Oeuf("Oeuf en chocalat", 50, 10);
        Oeuf oeuf2 = new Oeuf("Oeuf de poule", 100, 5);
        
        panier.ajouterOeuf(oeuf1);
        panier.ajouterOeuf(oeuf2);
    }
}
